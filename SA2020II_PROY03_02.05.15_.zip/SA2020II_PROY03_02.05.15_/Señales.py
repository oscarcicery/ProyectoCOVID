import requests
import json
import matplotlib.pyplot as plt

import numpy as np

ListaValor=[]
ListaLocalidad=[]
ListaEstado=[]
Lista=[]
Localidad=[]
Casos=[]

urlDatos = 'https://datosabiertos.bogota.gov.co/api/3/action/datastore_search_sql?'
urlDatosSQL = 'sql=SELECT "Localidad de residencia", count(*) as Cantidad from "b64ba3c4-9e41-41b8-b3fd-2da21d627558" GROUP BY "Localidad de residencia" ORDER BY "Localidad de residencia"'

req = requests.get(url=urlDatos+urlDatosSQL)
#print(req.json())
reqJson = req.json()
Datos = reqJson['result']['records']
i=0
for fila in Datos:
    for titulo,valor in fila.items():
        
        ListaValor.append(int(fila["cantidad"]))
        ListaLocalidad.append(fila["Localidad de residencia"])
        #ListaEstado.append(fila["Estado"])
    i=i+1


plt.figure(figsize=(11,5))
plt.barh(ListaLocalidad,ListaValor)
#plt.xticks(np.linspace(0,1000,25))
plt.xlabel('Numero de Casos')
plt.title("Casos Actuales en Bogota")
plt.grid()
plt.show()
##claro


"""
urlDatosSQLoc  = 'sql=SELECT "Localidad de residencia" from "b64ba3c4-9e41-41b8-b3fd-2da21d627558" GROUP BY "Localidad de residencia" ORDER BY "Localidad de residencia"'
reqLoc = requests.get(url=urlDatos+urlDatosSQLoc)
reqJsonLoc = req.json()
DatosLoc = reqJsonLoc['result']['records']

urlDatosSQLData  = 'sql=SELECT "Localidad de residencia", "Fecha de diagnostico", count(*) as Cantidad from "b64ba3c4-9e41-41b8-b3fd-2da21d627558" GROUP BY "Localidad de residencia", "Fecha de diagnostico" ORDER BY "Localidad de residencia", "Fecha de diagnostico"'
reqData = requests.get(url=urlDatos+urlDatosSQLData)
reqJsonData = req.json()
DatosData = reqJsonData['result']['records']


for fila in DatosLoc:
    ListaFecha=[]
    ListaValorCantidad=[]
    for titulo,valor in fila.items():
        if DatosData["Localidad de residencia"] == fila["Localidad de residencia"]:
            #ListaFecha.append(DatosData[""])
            ListaValorCantidad.append(int(fila["Cantidad"]))
            
#print(ListaFecha)
print(ListaValorCantidad)      
"""
AntonioN = lambda x: 18*((x)**2) - 38*(x) + 24
BarriosU = lambda x: -28*((x)**2)+120*(x)-82
Bosa = lambda x: -46.5*((x)**2)+294.5*(x)-233
Chapinero = lambda x: -52.5*((x)**2)+197.5*(x)-97
CBolivar = lambda x: -88*((x)**2)+407*(x)-313
Engativa = lambda x: -147.5*((x)**2)+619.5*(x)-409
Fontivon = lambda x: -44.5*((x)**2)+213.5*(x)-135
FueraDeB = lambda x: -12.5*((x)**2)+58.5*(x)-44
Kennedy = lambda x: -114.5*((x)**2)+772.5*(x)-622
LaCandelaria = lambda x: -1.5*((x)**2)-5.5*(x)-7
LosMartires = lambda x: -7.5*((x)**2)+45.5*(x)-34
PuenteAranda = lambda x: -40.5*((x)**2)+200.5*(x)-148
RafaelUU= lambda x: -46*((x)**2)+229*(x)-178
SanCristobal = lambda x: -30*((x)**2)+172*(x)-140
SanTafe = lambda x: 15*((x)**2)+5.5*(x)-3
SinDato = lambda x: 79*(x)-59
Suba = lambda x: -152*((x)**2)+639*(x)-399
Teusaquillo = lambda x: -61*((x)**2)+242*(x)-144
Tunjuelito = lambda x: -29*((x)**2)+135*(x)-99
Usaquen = lambda x: -127.5*((x)**2)+500.5*(x)-292
Usme = lambda x: -12.5*((x)**2)+91.5*(x)-74
##tabla1

##tabla1

x=np.linspace(1,4,100)
#x=np.arange(1,4,0.1)

plt.figure(figsize=(11,5))
plt.suptitle("Proyeccion de Contagio: Junio")
plt.subplot(2,2,1,)
plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.3, hspace=0.3)
plt.plot(x,AntonioN(x))
plt.title('Antonio Nariño')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,2)
plt.plot(x,BarriosU(x))
plt.title('BarriosU')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,3)
plt.plot(x,Bosa(x))
plt.title('Bosa')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,4)
plt.plot(x,Chapinero(x))
plt.title('Chapinero')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.show()
##tabla2
plt.figure(figsize=(11,5))
plt.suptitle("Proyeccion de Contagios: Junio")
plt.subplot(2,2,1,)
plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.3, hspace=0.3)
plt.plot(x,CBolivar(x))
plt.title('Ciudad Bolivar')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,2)
plt.plot(x,Engativa(x))
plt.title('Engativa')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,3)
plt.plot(x,Fontivon(x))
plt.title('Fontivon')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,4)
plt.plot(x,FueraDeB(x))
plt.title('Fuera De Bogota')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.show()
##Tabla3
plt.figure(figsize=(11,5))
plt.suptitle("Proyeccion de Contagio: Junio")
plt.subplot(2,2,1,)
plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.3, hspace=0.3)
plt.plot(x,Kennedy(x))
plt.title('Kennedy')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,2)
plt.plot(x,LaCandelaria(x))
plt.title('La Candelaria')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,3)
plt.plot(x,LosMartires(x))
plt.title('Los Martires')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,4)
plt.plot(x,PuenteAranda(x))
plt.title('Puente Aranda')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.show()
##tabla4
plt.figure(figsize=(11,5))
plt.suptitle("Proyeccion de Contagio: Junio")
plt.subplot(2,2,1,)
plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.3, hspace=0.3)
plt.plot(x,RafaelUU(x))
plt.title('Rafael Uribe Uribe')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,2)
plt.plot(x,SanCristobal(x))
plt.title('San Cristobal')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,3)
plt.plot(x,SanTafe(x))
plt.title('Santa Fe')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,4)
plt.plot(x,Suba(x))
plt.title('Suba')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.show()

##talba 5
plt.figure(figsize=(11,5))
plt.suptitle("Proyeccion de Contagio: Junio")
plt.subplot(2,2,1,)
plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.3, hspace=0.3)
plt.plot(x,Teusaquillo(x))
plt.title('Teusaquillo')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,2)
plt.plot(x,Tunjuelito(x))
plt.title('Tunjuelito')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,3)
plt.plot(x,Usaquen(x))
plt.title('Usaquen')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.subplot(2,2,4)
plt.plot(x,Usme (x))
plt.title('Usme')
plt.ylabel('Contagiados')
plt.xticks(np.linspace(1,4,4),["Marzo","Abril","Mayo","Junio"])
plt.grid()

plt.show()

##resumen
